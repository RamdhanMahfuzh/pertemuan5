<?php

$conn = mysqli_connect("localhost:3306", "root", "", "ecommerce")
    or die("Can't connect to the database");
